namespace PayStack.Net
{
    public enum ResendOtpReasons
    {
        ResendOtp,
        Transfer
    }
}