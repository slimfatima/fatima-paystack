﻿namespace PayStack.Net
{
    public class SubAccountUpdateResponse : SubAccountCreateResponse
    {
    }

    public class SubAccountUpdateRequest : SubAccountCreateRequest
    {
    }
}